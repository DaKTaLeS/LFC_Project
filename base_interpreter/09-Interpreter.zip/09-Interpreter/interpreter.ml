(* (2003)Originale ML(Marco Pistore & Floriano Zini) *)
(*    (2004)Estensione OCAML(Fabrizio Lazzarotto)    *)
(*          (2007)Revisione (Stefano Schivo)         *)
(*	        (2011) Revision (Nataliia Bielova)   *)

open Syntaxtree;;
(*** INTERPRETER DOMAINS ***)

(* memory *)
type loc = Loc of int
type value =
      ValueInt of int
    | ValueFloat of float

type store = loc -> value

type env_entry =  Var of loc
                | Val of value
                | Descr_Vector of loc * int * int
                | Descr_Procedure of param list * dec list * cmd

type env = ide -> env_entry

(* exception *)
exception NO_MEM
exception NO_IDE
exception SYNTAX
exception INDEX_OUT_OF_BOUNDS
exception INDEX_IS_FLOAT
exception DIFFERENT_TYPE_OPERATION
exception DIFFERENT_TYPE_ASSIGNATION
exception PARAMETERS_DO_NOT_MATCH
(******************************)

(* THE INTERPRETER *)

(* utility functions *)
let initenv (x:ide):env_entry = raise NO_IDE
let initmem (x:loc):value = raise NO_MEM

let updatemem ((s:store), addr, (v:value)) :store = function
    x -> if (x = addr) then v else s(x)

let updateenv ((e:env),id, (v:env_entry)) :env = function
    y -> if (y = id) then v else e(y)

let newmem (s: store) : int =   
    let rec aux n =
        try (let _=s(Loc(n)) in aux(n+1)) with NO_MEM -> n (* s(Loc(n)) is used only to read the memory at the location n, so to see whether that location is non-valid (which means free), and so we don't consider it's value *)
    in aux 0

let rec updatemem_vector((s:store), addr, length, (v:value)) :store =
    match length with
          1 ->  updatemem(s,addr,v)
        | n ->  let s' = updatemem(s,addr,v)
                in
                    updatemem_vector(s',Loc(newmem s'),n-1,v)


(* evaluation of arithmetical expressions *)
let rec eval_aexp (e:aexp) (r:env) (s:store) : value = match e with
      N(n)      ->  ValueInt(n)
    | R(n)      ->  ValueFloat(n)
    | Ident(i)  ->  (
                     match r(i) with
                          Var(l) -> s(l)
                        | Val(v) -> v
                        | _ -> raise SYNTAX
                    )
    | Vec(v,i)  ->  (
                     match r(v) with
                          Descr_Vector(Loc(vo),lb,ub) ->
			    let res =  (eval_aexp i r s) in (
				match res with 
				ValueFloat(_) -> raise INDEX_IS_FLOAT
				| ValueInt(pos) ->                             
                                if (pos >= lb && pos <= ub) then
                                    s(Loc(vo+pos))
                                else
                                    raise INDEX_OUT_OF_BOUNDS
				)
                        | _ -> raise SYNTAX
                    )
    
    | Sum (a,b) ->  aexp_op_fun a b r s (+) (+.)
    
    | Sub (a,b) ->  aexp_op_fun a b r s (-) (-.)
    
    | Mul (a,b) ->  let mi a b = a*b
                    in 
                        let mf a b = a*.b
                        in aexp_op_fun a b r s mi mf
    
    | Div (a,b) -> aexp_op_fun a b r s (/) (/.)


and aexp_op_fun  (a:aexp) (b:aexp) (r:env) (s:store) fi fr = 
    let aValue = (eval_aexp a r s)
        and bValue = (eval_aexp b r s)
    in (
         match aValue with 
             ValueInt(op1)      -> (
                                     match bValue with
                                          ValueInt(op2) -> ValueInt(fi op1 op2)
                                        | _ -> raise DIFFERENT_TYPE_OPERATION
                                    )
            | ValueFloat(op1)   -> (
                                     match bValue with
                                          ValueFloat(op2) -> ValueFloat(fr op1 op2)
                                        | _ -> raise DIFFERENT_TYPE_OPERATION
                                    )
        )


let rec eval_bexp (e:bexp) (r:env) (s:store) = match e with
      B(b)      ->  b
    | And (a,b) ->  ((eval_bexp a r s ) && (eval_bexp b r s ))
    | Or  (a,b) ->  ((eval_bexp a r s ) || (eval_bexp b r s ))
    | Equ (a,b) ->  ((eval_aexp a r s )  = (eval_aexp b r s ))
    | LE  (a,b) ->  ((eval_aexp a r s ) <= (eval_aexp b r s ))
    | LT  (a,b) ->  ((eval_aexp a r s )  < (eval_aexp b r s ))
    | Not (a)   ->  (not(eval_bexp a r s ))


(* evaluation of declarations *)
let rec eval_decs (d:dec list) (r:env) (s: store) = match d with
      []                        ->  (r,s)
    | Dec(x,Basic(bType))::decls ->  let newaddr = newmem s in
				     let r' =  (updateenv(r,x,Var(Loc(newaddr)))) 	
                                    in (
                                         match bType with
                                              Int   -> eval_decs decls r' (updatemem(s,Loc(newaddr),ValueInt(0)))
                                            | Float -> eval_decs decls r' (updatemem(s,Loc(newaddr),ValueFloat(0.0)))
                                        )
    | Dec(x,Const(bType,value_exp))::decls  
                                ->  let value = eval_aexp value_exp r s
                                    in 
                                    (
                                      match bType with
                                           Int  -> 
                                            (
                                             match value with
                                                  ValueInt(v) -> eval_decs decls (updateenv(r,x,Val(ValueInt(v)))) s
                                                | ValueFloat(v) -> raise DIFFERENT_TYPE_ASSIGNATION
                                            )
                                         | Float->
                                            (
                                             match value with
                                                  ValueFloat(v) -> eval_decs decls (updateenv(r,x,Val(ValueFloat(v)))) s
                                                | ValueInt(v) -> raise DIFFERENT_TYPE_ASSIGNATION
                                            )
                                    )
                                  
    | Dec(x,Vector(bType,lb,ub))::decls
                                ->  let newaddr = newmem s
                                    and dim = ub - lb + 1
                                    in
                                    let vo = Loc(newaddr - lb) in
				    let r' =  (updateenv(r,x,Descr_Vector(vo,lb,ub))) 
                                    in
                                    (
                                      match bType with
                                          Int -> eval_decs decls r' (updatemem_vector(s,Loc(newaddr),dim,ValueInt(0)))
                                        | Float -> eval_decs decls r' (updatemem_vector(s,Loc(newaddr),dim,ValueFloat(0.0)))
                                    )



(* evaluation of declarations of subprograms *)
let rec eval_sub_prog_decs (d: sub_prog list) ((r:env),(s:store)) = match d with
      [] -> (r,s)
    | Proc(id,params,locals,cmds)::decls ->
	let v = (Descr_Procedure(params,locals,cmds)) in
        eval_sub_prog_decs decls ((updateenv(r,id,v)),s)


(* evaluation of actual parameter list *)
let rec eval_actual_params (e:aexp list) (r:env) (s:store) = match e with
      []        ->  [] 
    | esp::vl   ->  (eval_aexp esp r s)::(eval_actual_params vl r s)



(* prepare for execution of subprograms *)

let type_checking (input_values:value list) (parameters:param list) = 

    let rec check_types (actuals:value list) (formals:param list) :bool =
        match (actuals,formals) with
              [],[] -> true
            | (v)::acts,Par(id,bType)::forms ->
                (
                 match v with
                      ValueInt(x) ->
                        if (bType=Int) then
                            (check_types acts forms)
                        else false
                    | ValueFloat(x) ->
                        if (bType=Float) then
                            (check_types acts forms)
                        else false
                )
            | _ -> raise SYNTAX
    in
        if (List.length(input_values)!= List.length(parameters))
            then false
        else
            (check_types input_values parameters)


let rec assign_values (formals:param list) (actuals:value list) ((r:env), (s: store)) =
    match (formals,actuals) with
          [],[] -> (r,s)
        | Par(id,bType)::forms,v::acts ->
            let (r',s') =
                assign_values forms acts (eval_decs[Dec(id,Basic(bType))] r s)
            in
                (
                 match r'(id) with
                      Var(l) -> (r',updatemem(s',l,v))
                    | _ -> raise SYNTAX
                )
        | _ -> raise SYNTAX





(* execution of commands *)
let rec exec (c: cmd) (r: env) (s: store) = match c with
    Ass(i,e)        ->  let ret = eval_aexp e r s
                        in 
                        (
                         match i with
                              LVar(id)  -> (
                                            match r(id) with
                                              Var(l)    -> updatemem(s,l,ret)
                                            | _         -> raise SYNTAX
                                           )
                            | LVec(v,idx) -> (
                                              match r(v) with
                                                  Descr_Vector(Loc(vo),lb,ub) ->
							let res = (eval_aexp idx r s) in (
							match res with 
							| ValueFloat(_) -> raise INDEX_IS_FLOAT
							| ValueInt(pos) ->                                                
                                                        if (pos >= lb && pos <= ub) then
                                                            updatemem(s,Loc(vo+pos),ret)
                                                        else
                                                            (
                                                             raise INDEX_OUT_OF_BOUNDS
                                                            )
							)
                                                | _ -> raise SYNTAX
                                             )
                        )
    | Blk([])       ->  s
    | Blk(x::y)     ->  exec (Blk(y)) r (exec x r s)
    | Ite(b,c1,c2)  ->  if (eval_bexp b r s) then (exec c1 r s)
                        else (exec c2 r s)
    | While(b,c)    ->  if (not(eval_bexp b r s)) then s
                        else
                            let s'' = exec c r s
                            in (exec (While(b,c)) r s'')
    | Repeat(c, b)  -> let s'' = exec c r s in
			if (eval_bexp b r s) then s''
			else (exec (Repeat(c,b)) r s'') 
    | For(i,valmin_exp,valmax_exp,c) 
                    ->  let valmin = eval_aexp valmin_exp r s
                        and update_counter l s =
                            match s(l) with
                              ValueInt(n) -> updatemem(s, l, ValueInt(n + 1))
                            | ValueFloat(f) -> updatemem(s, l, ValueFloat(f +. 1.0))
                        in 
                        (
                         match r(i) with
                              Var(l) -> 
                                (
                                let s0 = updatemem(s, l, valmin)
                                in
                                    let rec exec_for s =
                                        let s' = exec c r s
                                        in
                                            let ret = eval_bexp (LT(Ident(i), valmax_exp)) r s'
                                            in
                                                if (ret) then exec_for (update_counter l s')
                                                else s'
                                    in exec_for s0
                                )
                            | _ -> raise SYNTAX
                        )
    | Write(e)      ->  let ret = (eval_aexp e r s)
                        in
                        (
                         match ret with
                              ValueInt(op1) -> print_int(op1); print_string "\n";s
                            | ValueFloat(op1) -> print_float(op1); print_string "\n";s
                        )
    | PCall(id,input_exprs)
                    ->  let input_values = (eval_actual_params input_exprs r s)
                        in
                        (
                         match (r(id)) with
                              Descr_Procedure(params,locals,cmds) ->
                                if ((type_checking input_values params)) then
                                    exec_proc (r(id)) input_values r s
                                else
                                    raise PARAMETERS_DO_NOT_MATCH
                            | _ -> raise SYNTAX
                        )


(* execution of subprograms *)
and exec_proc (ee:env_entry) (input_values:value list) (r: env) (s: store) :store =

    let do_exec (formal_params: param list ) (local_decs: dec list) (com: cmd) (values:value list) (r: env) (s: store): store =
        let (r',s') = assign_values formal_params values (r,s)
        in
            let (r'',s'') = eval_decs local_decs r' s'
            in
                exec com r'' s''
    in
        match ee with
              Descr_Procedure(params,locals,com) ->
                do_exec params locals com input_values r s
            | _ -> raise SYNTAX


(* evaluation of programs *)
let run prog = 
    match prog with
        Program(vars,sub_progs,com) ->  let (r,s) = (eval_decs vars initenv initmem) in
					let (r',s') = (eval_sub_prog_decs sub_progs (r,s)) in 
					(exec com r' s')
      | Null -> initmem
